package integration.model;

public class JuegoTest {
}
