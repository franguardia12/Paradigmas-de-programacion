package org.tp1;

import org.tp1.model.Jugabilidad.Juego ;

public class Main {
    public static void main(String[] args) {
        Juego juego = new Juego(null);
        juego.inicializarJuego();
    }

}