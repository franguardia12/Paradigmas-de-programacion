package org.tp1.model.PokemonsDependencias;

import java.io.Serializable;

public enum Elemento implements Serializable {
    AGUA,
    BICHO,
    DRAGON,
    ELECTRICO,
    FANTASMA,
    FUEGO,
    HIELO,
    LUCHA,
    NORMAL,
    PLANTA,
    PSIQUICO,
    ROCA,
    TIERRA,
    VENENO,
    VOLADOR,
}
