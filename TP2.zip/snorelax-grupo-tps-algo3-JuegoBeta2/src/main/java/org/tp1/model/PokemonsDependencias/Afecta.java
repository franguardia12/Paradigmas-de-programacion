package org.tp1.model.PokemonsDependencias;

public enum Afecta {
    RIVAL,
    PROPIO,

    CLIMA,
}
