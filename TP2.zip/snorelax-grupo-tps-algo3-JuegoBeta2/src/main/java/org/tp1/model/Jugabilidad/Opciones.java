package org.tp1.model.Jugabilidad;

public enum Opciones {
    RENDIRSE,
    USAR_HABILIDAD,
    CAMPOBATALLA,
    INTERCAMBIAR_POKEMON,
    SELECCIONAR_ITEM,
}
