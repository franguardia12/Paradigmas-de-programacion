package org.tp1.model.PokemonsDependencias;

public interface Modificable {
    void modificar(Estadistica estadistica, double porcentaje);
}
