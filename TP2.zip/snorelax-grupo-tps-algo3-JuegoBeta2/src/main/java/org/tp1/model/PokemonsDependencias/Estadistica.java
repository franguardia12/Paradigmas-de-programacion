package org.tp1.model.PokemonsDependencias;

import java.io.Serializable;

public enum Estadistica implements Serializable {
    ATAQUE,
    DEFENSA,
    VIDA,
}
