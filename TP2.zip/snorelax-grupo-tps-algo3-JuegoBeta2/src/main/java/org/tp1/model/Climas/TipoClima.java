package org.tp1.model.Climas;

public enum TipoClima {
    SIN_CLIMA,
    SOLEADO,
    LLUVIA,
    TORMENTA_DE_ARENA,
    NIEBLA,
    TORMENTA_DE_RAYOS,
    HURACAN,
    NIEVE,
    ERUPCION_VOLCAN,
}
