package org.tp1.view;

public class AccionDeTurnoView {

    public AccionDeTurnoView() {
    }

    public static void mostrarAccionDeTurno(String texto) {
        System.out.println(texto);
    }
}
