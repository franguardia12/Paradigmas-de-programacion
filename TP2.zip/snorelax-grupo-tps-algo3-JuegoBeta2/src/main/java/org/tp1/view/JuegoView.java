package org.tp1.view;

public class JuegoView {
}
