package org.tp1.controller;

public class Mensaje {
    protected String info;

    public Mensaje() {
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getInfo() {
        return this.info;
    }
}
